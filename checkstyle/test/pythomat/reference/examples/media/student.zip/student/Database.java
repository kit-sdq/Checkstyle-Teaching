package student;

import java.util.Collections;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

import student.author.Creator;
import student.author.Person;
import student.media.MediaFile;

/**
keeps the references to the media-files and authors.
@author Markus Iser
@version 1
*/
public class Database {	
	private List<Creator> creators;
	private List<MediaFile> media;

	/**
	creates a new database instance.
	*/
	public Database() {
		creators = new ArrayList<Creator>();
		media = new ArrayList<MediaFile>();
	}
	
	/**
	add a creator to the database.
	@param creator the creator to add
	*/
	public void addCreator(Creator creator) {
		this.creators.add(creator);
	}

	/**
	add a media-file to the database.
	@param media the file to add
	*/
	public void addMedia(MediaFile media) {
		this.media.add(media);
	}
	
	/**
	collects and returns data that matches search term.
	@param term the search term
	@return a list of files/creators
	*/
	public List<Matchable> search(String term) {
		List<Matchable> list = new ArrayList<Matchable>();
		list.addAll(creators);
		list.addAll(media);
		List<Matchable> results = new ArrayList<Matchable>();
		Iterator<Matchable> iter = list.iterator();
		while (iter.hasNext()) {
			Matchable item = iter.next();
			if (item.match(term)) {
				results.add(item);
			}
		}
		return results;
	}
	
	/**
	collects and returns data that matches search term.
	@param term the search term
	@return a list of persons
	*/
	public ArrayList<Person> searchPerson(String term) {
		ArrayList<Person> results = new ArrayList<Person>();
		Iterator<Creator> iter = creators.iterator();
		while (iter.hasNext()) {
			Creator item = iter.next();
			if (item.match(term) && item instanceof Person) {
				results.add((Person) item);
			}
		}
		return results;
	}

	/**
	collects and returns data that matches search term.
	@param term the search term
	@return a list of creators
	*/
	public List<Creator> searchCreator(String term) {
		ArrayList<Creator> results = new ArrayList<Creator>();
		Iterator<Creator> iter = creators.iterator();
		while (iter.hasNext()) {
			Creator item = iter.next();
			if (item.match(term)) {
				results.add(item);
			}
		}
		return results;
	}
	
	/**
	creates a sorted list of strings using the toString()-method of the given Matchable objects.
	@param list a list of matchables
	@return a list of strings
	*/
	public List<String> createSortedListOfStrings(ArrayList<Matchable> list) {
		ArrayList<String> newList = new ArrayList<String>();
		// initialize
		for (Matchable element : list) {
			newList.add(element.toString());
		}
		Collections.sort(newList);
		return newList;
	}
}
