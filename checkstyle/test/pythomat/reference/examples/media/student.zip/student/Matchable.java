package student;

/**
Matchable.
@author Markus
@version 1
*/
public interface Matchable {
	/**
	Tolerated Distance for match returning true.
	*/
	double TOLERANCE = 0.25;
	
	/**
	Returns true if search string matches.
	@param str the search string
	@return true if search string matches
	*/
	boolean match(String str);
}
