package student;

import programmieren.MyTerminal;
import student.author.Creator;
import student.author.Artist;
import student.author.Person;
import student.author.Band;
import student.media.Audio;
import student.media.Video;

import java.util.ArrayList;
import java.util.List;

/**
Interactive Shell.
@author markus
@version 1
*/
public final class Shell
{
	private static final String PROMPT = "> ";
	private static final String ENTER_COMMAND = "Enter command (add|search|quit)";
	private static final String ENTER_TYPE = "Enter entry type (person|artist|band|audio|video)";
	private static final String ENTER_GIVEN_NAME = "Enter given name";
	private static final String ENTER_FAMILY_NAME = "Enter family name";
	private static final String ENTER_PSEUDONYM = "Enter pseudonym";
	private static final String ENTER_BAND_NAME = "Enter band name";
	private static final String ENTER_MEMBER = "Enter member or 'quit'";
	private static final String ENTER_SEARCH_TERM = "Enter search term";
	private static final String ENTER_URI = "Enter URI";
	private static final String ENTER_CREATOR = "Enter creator";
	private static final String ENTER_DURATION = "Enter duration (as integer)";
	private static final String ENTER_WIDTH = "Enter width (as integer)";
	private static final String ENTER_HEIGHT = "Enter height (as integer)";

	private static final String MESSAGE_NOT_FOUND = "No matches found";
	private static final String MESSAGE_NOT_UNIQUE = "No unique match found";
	private static final String MESSAGE_INVALID = "Invalid input";

	private static final String COMMAND_ADD = "add";
	private static final String COMMAND_SEARCH = "search";
	private static final String COMMAND_QUIT = "quit";

	private static final String TYPE_PERSON = "person";
	private static final String TYPE_ARTIST = "artist";
	private static final String TYPE_BAND = "band";
	private static final String TYPE_AUDIO = "audio";
	private static final String TYPE_VIDEO = "video";

	private Database database;

	private Shell() {
		database = new Database();
	}

	/**
	Interactive Shell. Main Program.
	@param args the program arguments
	*/
	public static void main(String[] args) {
		Shell shell = new Shell();

		boolean cont = true;
		do {
			cont = shell.execute();
		} while (cont);
	}

	private static String promptString(String message) {
		return MyTerminal.askString(message + PROMPT);
	}

	private static int promptInt(String message) {
		return MyTerminal.askInt(message + PROMPT);
	}
	
	private static void print(String message) {
		System.out.println(message);
	}

	private boolean execute() {
		switch (promptString(ENTER_COMMAND).trim()) {
			case COMMAND_ADD:
				// go into add mode
				addSomething();
				return true;
			case COMMAND_SEARCH:
				// go into search mode
				searchSomething();
				return true;
			case COMMAND_QUIT:
				return false;
			default:
				print(MESSAGE_INVALID);
				return true;
		}
	}

	private void addSomething() {
		String command = promptString(ENTER_TYPE);
		switch (command) {
			case TYPE_PERSON:
				database.addCreator(addPerson());
				return;
			case TYPE_ARTIST:
				database.addCreator(addArtist());
				return;
			case TYPE_BAND:
				database.addCreator(addBand());
				return;
			case TYPE_AUDIO:
				Audio audio = addAudio();
				if (audio != null) {
					database.addMedia(audio);
				}
				return;
			case TYPE_VIDEO:
				Video video = addVideo();
				if (video != null) {
					database.addMedia(video);
				}
				return;
			default:
				print(MESSAGE_INVALID);
		}
	}

	private Person addPerson() {
		String givenName = promptString(ENTER_GIVEN_NAME);
		String familyName = promptString(ENTER_FAMILY_NAME);
		return new Person(givenName, familyName);
	}

	private Artist addArtist() {
		String givenName = promptString(ENTER_GIVEN_NAME);
		String familyName = promptString(ENTER_FAMILY_NAME);
		String pseudonym = promptString(ENTER_PSEUDONYM);
		return new Artist(givenName, familyName, pseudonym);
	}

	private Band addBand() {
		String bandname = promptString(ENTER_BAND_NAME);
		List<Person> members = new ArrayList<Person>();
		boolean cont = true;
		do {
			String term = promptString(ENTER_MEMBER);
			if (term.equals(COMMAND_QUIT)) {
				cont = false;
			} else {
				List<Person> matches = database.searchPerson(term);
				if (matches.size() == 1) {
					members.add(matches.get(0));
				} else {
					print(MESSAGE_NOT_UNIQUE);
				}
			}
		} while (cont);

		return new Band(bandname, members.toArray(new Person[members.size()]));
	}

	private Audio addAudio() {
		String uri = promptString(ENTER_URI);
		Creator creator = searchCreator(promptString(ENTER_CREATOR));
		if (creator != null) {
			return new Audio(uri, creator, promptInt(ENTER_DURATION));
		} else {
			return null;
		}
	}

	private Video addVideo() {
		String uri = promptString(ENTER_URI);
		Creator creator = searchCreator(promptString(ENTER_CREATOR));
		if (creator != null) {
			int width = promptInt(ENTER_WIDTH);
			int height = promptInt(ENTER_HEIGHT);
			return new Video(uri, creator, width, height);
		} else {
			return null;
		}
	}

	private Creator searchCreator(String term) {
		List<Creator> matches = database.searchCreator(term);
		if (matches.size() == 1) {
			return matches.get(0);
		} else {
			print(MESSAGE_NOT_UNIQUE);
			return null;
		}
	}

	private Person searchPerson(String term) {
		List<Person> matches = database.searchPerson(term);
		if (matches.size() == 1) {
			return matches.get(0);
		} else {
			print(MESSAGE_NOT_UNIQUE);
			return null;
		}
	}

	private void searchSomething() {
		List<Matchable> result = database.search(promptString(ENTER_SEARCH_TERM));

		if (result.isEmpty()) {
			print(MESSAGE_NOT_FOUND);
		} else {
			for (Matchable entry : result) {
				if (entry != null) {
					print(entry.toString());
				}
			}
		}
	}

}
