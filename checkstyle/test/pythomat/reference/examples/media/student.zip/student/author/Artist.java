package student.author;

import student.metrics.Levenshtein;

/**
An artist is a person with a pseudonym.
@author markus
@version 1
*/
public class Artist extends Person {
	/** the pseudonym. */
	private final String pseudonym;
	
	/**
	dummy comment.	
	@param firstName dummy
	@param lastName dummy 
	@param pseudonym dummy
	*/
	public Artist(String firstName, String lastName, String pseudonym) {
		super(firstName, lastName);
		this.pseudonym = pseudonym;
	}
	
	/**
	dummy comment.	
	@return dummy return
	*/
	@Override
	public String getName() {
		return getPseudonym();
	}

	/**
	dummy comment.	
	@return dummy return
	*/	
	public String getPseudonym() {
		return pseudonym;
	}

	/**
	dummy comment.	
	@param str dummy
	@return dummy return
	*/	
	@Override
	public boolean match(String str) {
		boolean result = super.match(str);
		result |= Levenshtein.getNormalizedDistance(str, pseudonym) < TOLERANCE;
		return result;
	}

	/**
	dummy comment.	
	@return dummy return
	*/
	@Override
	public String toString() {
		return getFirstName() + " \"" + getPseudonym() + "\" " + getLastName();
	}
}
