package student.author;

import student.metrics.Levenshtein;

/**
A band is a creator with multiple persons as members.
@author markus
@version 1
*/
public class Band extends Creator {
	private final String name;
	private final Person[] members;
	
	/**
	dummy comment.	
	@param name dummy
	@param members dummy
	*/
	public Band(String name, Person[] members) {
		this.name = name;
		this.members = members;
	}

	/**
	dummy comment.	
	@return dummy return
	*/	
	public Person[] getMembers() {
		return members;
	}

	/**
	dummy comment.	
	@return dummy return
	*/
	@Override
	public String getName() {
		return name;
	}

	/**
	dummy comment.	
	@param str dummy
	@return dummy return
	*/	
	@Override
	public boolean match(String str) {
		boolean result = super.match(str);
		result |= Levenshtein.getNormalizedDistance(str, name) < TOLERANCE;
		for (Person member : members) {
			result |= member.match(str);
		}		
		return result;
	}

	/**
	dummy comment.	
	@return dummy return
	*/
	public String toString() {
		StringBuilder result = new StringBuilder();
		result.append(getName() + " (");
		for (int i = 0; i != members.length; ++i) {
			result.append(members[i].toString());

			if (i != members.length - 1) {
				result.append(", ");
			}
		}
		result.append(')');
		return result.toString();
	}
}
