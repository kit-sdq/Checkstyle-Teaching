package student.author;

import student.Matchable;
import student.metrics.Levenshtein;

/**
An artist is matchable and has a name.
@author markus
@version 1
*/
public abstract class Creator implements Matchable {
	
	/**
	dummy comment.	
	@return dummy return
	*/
	public abstract String getName();

	/**
	dummy comment.	
	@param str dummy
	@return dummy return
	*/	
	@Override
	public boolean match(String str) {
		return Levenshtein.getNormalizedDistance(str, getName()) < TOLERANCE;
	}

	/**
	dummy comment.	
	@return dummy return
	*/
	public String toString() {
		return getName();
	}
}
