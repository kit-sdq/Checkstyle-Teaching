package student.author;

import student.metrics.Levenshtein;

/**
a person with has a firstname and a lastname.
@author markus
@version 1
*/
public class Person extends Creator {

	private final String firstName;
	private final String lastName;
		
	/**
	dummy comment.	
	@param firstName dummy
	@param lastName dummy
	*/
	public Person(String firstName, String lastName) {
		this.firstName = firstName;
		this.lastName = lastName;
	}

	/**
	dummy comment.	
	@return dummy return
	*/
	@Override
	public String getName() {
		return firstName + " " + lastName;
	}

	/**
	dummy comment.	
	@param str dummy
	@return dummy return
	*/	
	@Override
	public boolean match(String str) {
		boolean result = super.match(str);
		result |= Levenshtein.getNormalizedDistance(str, firstName) < TOLERANCE;
		result |= Levenshtein.getNormalizedDistance(str, lastName) < TOLERANCE;
		return result;
	}

	/**
	dummy comment.	
	@return dummy return
	*/	
	public String getFirstName() {
		return firstName;
	}

	/**
	dummy comment.	
	@return dummy return
	*/	
	public String getLastName() {
		return lastName;
	}
}
