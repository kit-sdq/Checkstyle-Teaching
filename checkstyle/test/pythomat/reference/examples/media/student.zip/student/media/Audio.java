package student.media;

import student.author.Creator;

/**
dummy.
@author dummy
@version 1
*/
public class Audio extends MediaFile {
	
	private int duration;

    /**
	dummy comment.	
	@param uri dummy
	@param creator dummy 
	@param duration dummy
	*/
	public Audio(String uri, Creator creator, int duration) {
		super(uri, creator);
		this.duration = duration;
	}

    /**
     * dummy.
     * @return dummy
    */
	public int getDuration() {
		return duration;
	}

    /**
     * dummy.
     * @return dummy
    */
	public String toString() {
		return super.toString() + " (" + getDuration() + "s)";
	}
}
