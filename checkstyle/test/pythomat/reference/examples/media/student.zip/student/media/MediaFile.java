package student.media;

import student.Matchable;
import student.author.Creator;
import student.metrics.Levenshtein;

/**
dummy.
@author dummy
@version 1
*/
public class MediaFile implements Matchable {
	
	private String uri;
	private Creator author;
    
    /**
	dummy comment.	
	@param uri dummy
	@param creator dummy 
	*/
	public MediaFile(String uri, Creator creator) {
		this.uri = uri;
		this.author = creator;
	}

    /**
     * dummy.
     * @return dummy
    */
	public String getUri() {
		return uri;
	}

    /**
     * dummy.
     * @return dummy
    */
	public Creator getAuthor() {
		return author;
	}

    /**
     * dummy.
     * @param str dummy
     * @return dummy
    */
	@Override
	public boolean match(String str) {
		return Levenshtein.getNormalizedDistance(str, uri) < TOLERANCE | author.match(str);
	}

    /**
     * dummy.
     * @return dummy
    */
	public String toString() {
		return getUri() + " by " + getAuthor();
	}
}
