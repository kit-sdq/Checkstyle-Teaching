package student.media;

import student.author.Creator;
import student.metrics.Levenshtein;

/**
dummy.
@author dummy
@version 1
*/
public class Music extends Audio {
	
	private String genre;
	
    /**
	dummy comment.	
	@param uri dummy
	@param creator dummy 
	@param duration dummy
	*/
	public Music(String uri, Creator creator, int duration) {
		this(uri, creator, duration, "");
	}
	
    /**
	dummy comment.	
	@param uri dummy
	@param creator dummy 
	@param duration dummy
    @param genre dummy
	*/
	public Music(String uri, Creator creator, int duration, String genre) {
		super(uri, creator, duration);
		this.genre = genre;
	}
	
    /**
     * dummy.
     * @param str dummy
     * @return dummy
    */
	@Override
	public boolean match(String str) {
		boolean result = super.match(str);
		result |= Levenshtein.getNormalizedDistance(genre.toString(), str) < TOLERANCE;
		return result;
	}

    /**
     * dummy.
     * @return dummy
    */
	public String toString() {
		return super.toString() + " (" + genre + ")";
	}
}
