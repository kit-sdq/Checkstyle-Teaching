package student.media;

import student.author.Creator;

/**
dummy.
@author dummy
@version 1
*/
public class Video extends MediaFile {
	
	private int width;
	private int height;
	
    /**
	dummy comment.	
	@param uri dummy
	@param creator dummy 
	@param width dummy
    @param height dummy
	*/
	public Video(String uri, Creator creator, int width, int height) {
		super(uri, creator);
		this.width = width;
		this.height = height;
	}

    /**
     * dummy.
     * @return dummy
    */
	public int getWidth() {
		return width;
	}

    /**
     * dummy.
     * @return dummy
    */
	public int getHeight() {
		return height;
	}

    /**
     * dummy.
     * @return dummy
    */
	public String toString() {
		return super.toString() + " (" + width + "x" + height + ")";
	}
}
