package student.metrics;

/**
 * Can caluclate the Levenshtein-Distance of two Strings. 
 * Class is meant for static usage, the sole constructor is private.  
 * 
 * @author Markus Iser
 * @version 1.2
 */
public final class Levenshtein {
    private final String w1;
    private final String w2;
    private int[][] distance;

    private Levenshtein(String w1, String w2) {
        this.w1 = "." + w1.toLowerCase();
        this.w2 = "." + w2.toLowerCase();
        this.distance = new int[this.w2.length()][this.w1.length()];
    }

    /**
     * Calculates the Levenshtein-Matrix for w1 and w2 and returns their normalized distance.
     * @param w1 The first String
     * @param w2 The second String
     * @return The Normalized Levenshtein-Distance of the first and second String
     */
    public static double getNormalizedDistance(String w1, String w2) {
    	Levenshtein levi = new Levenshtein(w1, w2);
    	double distance = levi.getDistance();
    	double maxDistance = Math.max(w1.length(), w2.length());
    	return distance / maxDistance;
    }
    
    /**
     * Calculates the Levenshtein-Matrix for w1 and w2 and returns their distance.
     * @param w1 The first String
     * @param w2 The second String
     * @return The Levenshtein-Distance of the first and second String
     */
    public static int getDistance(String w1, String w2) {
    	Levenshtein levi = new Levenshtein(w1, w2);
    	return levi.getDistance();
    }

    private int getDistance() {
        distance[0][0] = 0;
        for (int i = 0; i < w2.length(); i++) {
			for (int j = 0; j < w1.length(); j++) {
				if (i != 0 || j != 0) {
					distance[i][j] = Math.min(replace(i, j), 
									 Math.min(delete(i, j), insert(i, j)));
				}
			}
		}
		return distance[w2.length() - 1][w1.length() - 1];
    }

    private int getDistanceAt(int i, int j) {
		if (i < 0 || j < 0 || i > w2.length() || j > w1.length()) {
			return Integer.MAX_VALUE - 1;
		}
		return distance[i][j];
	}

    private int delete(int i, int j) {
        return getDistanceAt(i, j - 1) + 1;
    }

    private int insert(int i, int j) {
        return getDistanceAt(i - 1, j) + 1;
    }

    private int replace(int i, int j) {
        return w2.charAt(i) == w1.charAt(j) ? getDistanceAt(i - 1, j - 1) : getDistanceAt(i - 1, j - 1) + 1;
    }
}
